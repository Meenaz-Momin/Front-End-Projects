function Header() {
  return (
    <div className="heading">
      <h1>Employee List</h1>
    </div>
  );
}

export default Header;
