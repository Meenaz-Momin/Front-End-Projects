const FeedbackData = [
  {
    id: 1,
    rating: 10,
    text: "1st description of feedback",
  },
  {
    id: 2,
    rating: 9,
    text: "1st description of feedback",
  },
  {
    id: 3,
    rating: 8,
    text: "1st description of feedback",
  },
];

export default FeedbackData;
